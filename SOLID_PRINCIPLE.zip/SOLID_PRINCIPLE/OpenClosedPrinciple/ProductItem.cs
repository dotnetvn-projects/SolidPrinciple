﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenClosedPrinciple
{
    class ProductItem
    {
        public string Name { get; set; }
    }
}
