﻿namespace OpenClosedPrinciple
{
    public enum FileType
    {
        Image,
        Text,
        Exe
    }
}
