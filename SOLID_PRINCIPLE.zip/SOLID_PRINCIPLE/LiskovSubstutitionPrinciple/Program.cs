﻿using LiskovSubstutitionPrinciple.Before_Liskov;
using System;
using System.Runtime.InteropServices;

namespace LiskovSubstutitionPrinciple
{
    class Program
    {
        // Before using Liskov
        static void Main(string[] args)
        {
            Buyer linhPham = new Buyer
            {
                Name = "Linh Pham",
                Address = "HCM CITY",
                PhoneNumber = "1123243222"
            };
            PropertyContract contract = new CityContract(linhPham);
            contract.CreateRentContract();
            Console.WriteLine("");
            contract.CreateBuyContract();
            Console.WriteLine("");

            Buyer linhPham2 = new Buyer
            {
                Name = "Linh Pham 2",
                Address = "AN GIANG",
                PhoneNumber = "32423423"
            };
            contract = new RemoteAreaContract(linhPham2);
            contract.CreateRentContract();
            Console.WriteLine("");
            contract.CreateBuyContract();
            Console.WriteLine("");

            Buyer foreigner = new Buyer
            {
                Name = "Donal Trump",
                Address = "Washington, United states",
                PhoneNumber = "2132324324"
            };
            contract = new ForeignerContract(foreigner);
            contract.CreateRentContract();
            Console.WriteLine("");
            contract.CreateBuyContract();
        }
    }
}
