﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LiskovSubstutitionPrinciple.Before_Liskov
{
    class CityContract: PropertyContract
    {
        public CityContract(Buyer buyer): base(buyer) { }

        public override void CreateBuyContract()
        {
            base.CreateBuyContract();
            Console.WriteLine("Tax for City People is 15% / contract");
        }

        public override void CreateRentContract()
        {
            base.CreateRentContract();
            Console.WriteLine("Renting time is 1 years");
            Console.WriteLine("Tax for City People is 15% / contract");
        }
    }
}
