﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LiskovSubstutitionPrinciple.Before_Liskov
{
    class PropertyContract
    {//https://raygun.com/blog/solid-design-principles/
        private Buyer _buyer;

        public PropertyContract(Buyer buyer)
        {
            _buyer = buyer;
        }

        public virtual void CreateRentContract()
        {
            Console.WriteLine("Renting Contract created sucessull!.");
            Console.WriteLine($@"Buyer Information: Name: {_buyer.Name}, Phone: {_buyer.PhoneNumber}, Address: {_buyer.Address}");
        }

        public virtual void CreateBuyContract()
        {
            Console.WriteLine("Buying Contract created sucessull!.");
            Console.WriteLine($@"Buyer Information: Name: {_buyer.Name}, Phone: {_buyer.PhoneNumber}, Address: {_buyer.Address}");
        }
    }
}
